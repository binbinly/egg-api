// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminCommon = require('../../../app/controller/admin/common');
import ExportAdminGift = require('../../../app/controller/admin/gift');
import ExportAdminHome = require('../../../app/controller/admin/home');
import ExportAdminLive = require('../../../app/controller/admin/live');
import ExportAdminManager = require('../../../app/controller/admin/manager');
import ExportAdminOrder = require('../../../app/controller/admin/order');
import ExportAdminUser = require('../../../app/controller/admin/user');
import ExportApiCommon = require('../../../app/controller/api/common');
import ExportApiGift = require('../../../app/controller/api/gift');
import ExportApiLive = require('../../../app/controller/api/live');
import ExportApiUser = require('../../../app/controller/api/user');

declare module 'egg' {
  interface IController {
    admin: {
      common: ExportAdminCommon;
      gift: ExportAdminGift;
      home: ExportAdminHome;
      live: ExportAdminLive;
      manager: ExportAdminManager;
      order: ExportAdminOrder;
      user: ExportAdminUser;
    }
    api: {
      common: ExportApiCommon;
      gift: ExportApiGift;
      live: ExportApiLive;
      user: ExportApiUser;
    }
  }
}
