export default {
	/*
	注意：以下接口改成你自己部署的后端（老师提供的api接口已关闭），不懂的请看：课时127-131这几节课。
	*/
	
	baseUrl:"http://liveapi2.dishait.cn",
	socketUrl:"http://liveapi2.dishait.cn",
	imageUrl:"http://liveapi2.dishait.cn",
	
	// 拉流前缀
	livePlayBaseUrl:"http://liveapi2.dishait.cn:23481",
	// 推流前缀
	livePushBaseUrl:"rtmp://liveapi2.dishait.cn:23480",

}